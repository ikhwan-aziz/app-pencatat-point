# Books-Manager
A web app based on NodeJS and MongoDB allowing the users to Add, Search, Update and Delete Books  from the database. The app gives the user a modern and easy to use UI to easily search  among all the stored books making it easier to find the physical location  of the desired book.
